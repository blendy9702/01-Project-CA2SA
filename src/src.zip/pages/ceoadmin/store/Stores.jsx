function Stores() {
  return <div>Stores</div>;
}

export default Stores;
