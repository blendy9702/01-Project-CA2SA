function StoreInfo() {
  return <div>StoreInfo</div>;
}

export default StoreInfo;
