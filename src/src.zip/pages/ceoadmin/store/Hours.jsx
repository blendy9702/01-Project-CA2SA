function Hours() {
  return <div>Hours</div>;
}

export default Hours;
