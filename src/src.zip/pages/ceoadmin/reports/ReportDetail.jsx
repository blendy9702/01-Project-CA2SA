function ReportDetail() {
  return <div>ReportDetail</div>;
}

export default ReportDetail;
