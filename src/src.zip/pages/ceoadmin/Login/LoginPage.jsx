function LoginPage() {
  return <div>LoginPage</div>;
}

export default LoginPage;
