function ResetPassword() {
  return <div>ResetPassword</div>;
}

export default ResetPassword;
