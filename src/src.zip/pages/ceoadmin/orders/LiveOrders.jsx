function LiveOrders() {
  return <div>LiveOrders</div>;
}

export default LiveOrders;
