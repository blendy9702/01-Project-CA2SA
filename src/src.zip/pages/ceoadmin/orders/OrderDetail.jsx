function OrderDetail() {
  return <div>OrderDetail</div>;
}

export default OrderDetail;
