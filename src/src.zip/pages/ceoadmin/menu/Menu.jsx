function Menu() {
  return <div>Menu</div>;
}

export default Menu;
