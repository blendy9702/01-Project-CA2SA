function OedersDetails() {
  return <div>OedersDetails</div>;
}

export default OedersDetails;
