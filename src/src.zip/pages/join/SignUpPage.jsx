const SignUpPage = () => {
  const initData = [
    {
      nickName: "홍길동",
      email: "yaho@gmail.com",
      upw: "1111",
      agree: 1,
    },
  ];
  return <div>SignUpPage</div>;
};

export default SignUpPage;
