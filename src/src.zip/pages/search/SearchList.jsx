const SearchList = () => {
  return <div>SearchList</div>;
};

export default SearchList;
